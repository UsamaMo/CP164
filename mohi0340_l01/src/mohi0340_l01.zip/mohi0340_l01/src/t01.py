"""
-------------------------------------------------------
[Lab 1 Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-16"
-------------------------------------------------------
"""

from Food import Food

origins = Food.origins()

print(origins)
