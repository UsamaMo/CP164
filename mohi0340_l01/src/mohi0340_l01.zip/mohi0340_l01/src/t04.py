"""
-------------------------------------------------------
[Lab 1 Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-16"
-------------------------------------------------------
"""
from Food import Food
from Food_utilities import read_food

line = "Spanakopita|5|True|260"


f = read_food(line)

print(f)
