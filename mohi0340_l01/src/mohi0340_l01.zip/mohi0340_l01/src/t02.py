"""
-------------------------------------------------------
[Lab 1 Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-16"
-------------------------------------------------------
"""

from Food import Food

butter_chicken = Food('Butter Chicken', 2, False, 490)

f = butter_chicken


s = str(f)
print(f)
