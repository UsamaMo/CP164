"""
-------------------------------------------------------
[Lab 1 Task 3]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-16"
-------------------------------------------------------
"""

from Food_utilities import get_food

f = get_food()

print()
print(f)
