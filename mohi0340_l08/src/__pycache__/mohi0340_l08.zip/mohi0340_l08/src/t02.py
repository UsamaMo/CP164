"""
-------------------------------------------------------
[Lab 8 Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-03-13"
-------------------------------------------------------
"""

from morse import ByCode

a1 = ByCode('B', '-...')

a2 = ByCode('A', '.-')

print("Comparing using Morse Codes: (A,B)")
print(a1 > a2)
