"""
-------------------------------------------------------
[Lab 8 Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-03-13"
-------------------------------------------------------
"""

from morse import ByLetter


a1 = ByLetter('B', '-...')

a2 = ByLetter('A', '.-')


print("Comparing using Morse Code Letters: (A,B)")
print(a1 > a2)
