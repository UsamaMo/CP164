"""
-------------------------------------------------------
[Lab 2 Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-23"
-------------------------------------------------------
"""
from copy import deepcopy
from Stack_array import Stack
from utilities import stack_test

stack = Stack()
source = ['8']

stack_test(source)
