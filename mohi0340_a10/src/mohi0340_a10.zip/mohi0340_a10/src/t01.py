"""
-------------------------------------------------------
[Assignment 10 Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-04-01"
-------------------------------------------------------
"""

from Sorts_array import Sorts

array = [15, 54, 23, 2, 44, 80, 24, 66, 73, 33]

Sorts.radix_sort(array)

print(array)
