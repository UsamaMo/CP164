"""
-------------------------------------------------------
[Lab 4 Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-02-06"
-------------------------------------------------------
"""

from Food import Food

food = Food("Teriyaki", 6, None, None)

print(food)
