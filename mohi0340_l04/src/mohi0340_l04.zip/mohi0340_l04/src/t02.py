"""
-------------------------------------------------------
[Lab 4 Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-02-06"
-------------------------------------------------------
"""


from List_array import List

list = List()

list.append(50)


for i in list:
    print(i)
