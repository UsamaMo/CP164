"""
-------------------------------------------------------
[Lab 5 Task 6]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-02-20"
-------------------------------------------------------
"""

from functions import bag_to_set


bag = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

new_set = bag_to_set(bag)

print(f"New Set: {new_set}")
