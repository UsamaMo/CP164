"""
-------------------------------------------------------
[Lab 5 task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-02-20"
-------------------------------------------------------
"""

from functions import is_palindrome

s = input("String: ")

palindrome = is_palindrome(s)

print(palindrome)
