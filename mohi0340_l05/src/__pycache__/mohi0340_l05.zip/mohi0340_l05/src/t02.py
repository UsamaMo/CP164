"""
-------------------------------------------------------
[Lab 5 Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-02-20"
-------------------------------------------------------
"""

from functions import gcd

n = int(input("Number 1: "))
m = int(input("Number 2: "))


ans = gcd(m, n)

print()
print(f"Answer: {ans}")
