"""
-------------------------------------------------------
[Lab 5 Task 3]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-02-20"
-------------------------------------------------------
"""

from functions import vowel_count

s = input("String: ")

count = vowel_count(s)

print(f"Vowel Count: {count}")
