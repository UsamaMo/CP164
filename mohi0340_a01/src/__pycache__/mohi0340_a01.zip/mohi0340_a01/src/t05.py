"""
-------------------------------------------------------
[Assignment 1 Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-14"
-------------------------------------------------------
"""

from functions import is_palindrome

s = input("String: ")

palindrome = is_palindrome(s)

print(f">>> print(palindrome('{s}'))")
print(palindrome)
