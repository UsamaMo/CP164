"""
-------------------------------------------------------
[Assignment 1 Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-14"
-------------------------------------------------------
"""

from functions import is_leap_year

year = int(input("Leap Year: "))

leap_year = is_leap_year(year)

print(leap_year)
