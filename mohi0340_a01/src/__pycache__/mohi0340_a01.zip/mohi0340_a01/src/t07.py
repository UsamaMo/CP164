"""
-------------------------------------------------------
[Assignment 1 Task 7]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-14"
-------------------------------------------------------
"""

from functions import matrix_transpose

a = [[3, 2, 1], [1, 2, 7], [5, 9, 8]]

b = matrix_transpose(a)

print(b)
