"""
-------------------------------------------------------
[Assignment 1 Task 6]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-15"
-------------------------------------------------------
"""

from functions import max_diff

a = [3, -5, 5, 11, 7]

md = max_diff(a)

print(f">>> print(max_diff([{a}]))")
print(md)
