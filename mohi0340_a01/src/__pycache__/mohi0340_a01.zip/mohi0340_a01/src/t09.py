"""
-------------------------------------------------------
[Assignment 1 Task 9]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-14"
-------------------------------------------------------
"""

from functions import pig_latin

word = input("Word: ")

pl = pig_latin(word)

print(f"Pig-Latin: {pl}")
