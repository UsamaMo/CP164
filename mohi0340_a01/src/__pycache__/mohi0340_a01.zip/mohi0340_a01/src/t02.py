"""
-------------------------------------------------------
[Assignment 1 Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-14"
-------------------------------------------------------
"""

from functions import dsmvwl

s = "I think your book is an utter piece of Garbage."


out = dsmvwl(s)

print(f"Sentence: {s}")
print(f"Disemvowelled: {out}")
