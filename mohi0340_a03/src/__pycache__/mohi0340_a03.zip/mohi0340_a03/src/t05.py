"""
-------------------------------------------------------
[Assignment 3 Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-29"
-------------------------------------------------------
"""


from functions import is_palindrome_stack

string = input("Enter a string: ")

palindrome = is_palindrome_stack(string)

print(palindrome)
