"""
-------------------------------------------------------
[Assignment 2 Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-01-22"
-------------------------------------------------------
"""

from Food import Food
from Food_utilities import read_foods, food_search

file_variable = open("foods.txt", "r")

foods = read_foods(file_variable)


origin = int(input("Origins: "))
max_cals = int(input("Maximum Calories: "))
is_veg = False
print()


result = food_search(foods, origin, max_cals, is_veg)

for i in result:
    print(i)
    print()
