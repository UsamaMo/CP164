"""
-------------------------------------------------------
[Lab 9 Task 3]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-03-20"
-------------------------------------------------------
"""

from Hash_Set_array import Hash_Set

hash = Hash_Set(4)

hash.insert(1)

hash.insert(2)

hash.insert(3)

hash.insert(4)

hash.debug()
