"""
-------------------------------------------------------
[Lab 10 Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:            212090340
Email:    mohi0340@mylaurier.ca
__updated__ = "2022-03-27"
-------------------------------------------------------
"""

from test_Sorts_array import create_sorted, create_reversed, create_randoms

values1 = create_sorted()

print("Sorted Values: ")
print(values1[1])

values2 = create_reversed()

print()
print("Reversed Value:  ")
print(values2[1])

values3 = create_randoms()

print()
print("Random Values: ")
print(values3[1][1])
